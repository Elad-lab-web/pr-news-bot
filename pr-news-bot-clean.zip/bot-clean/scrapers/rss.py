import asyncio
import aiohttp
import feedparser
import logging
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass

logger = logging.getLogger(__name__)

NEWS_FEEDS = {
    # === חדשות כלליות ===
    "ynet":             "https://www.ynet.co.il/Integration/StoryRss2.xml",
    "ynet_24":          "https://www.ynet.co.il/Integration/StoryRss1854.xml",
    "walla_news":       "https://rss.walla.co.il/feed/1",
    "mako_news":        "https://rcs.mako.co.il/rss/news-military.xml",
    "n12":              "https://www.mako.co.il/rss/31750a2610f26110VgnVCM1000005201000aRCRD.xml",
    "kan_news":         "https://www.kan.org.il/rss/",
    "channel13":        "https://13tv.co.il/rss/",
    "channel14":        "https://www.now14.co.il/feed/",
    "haaretz":          "https://www.haaretz.co.il/srv/haaretz-rss",
    "maariv":           "https://www.maariv.co.il/rss/rssfeedindex.aspx",
    "israelhayom":      "https://www.israelhayom.co.il/rss.xml",
    "zman":             "https://www.zman.co.il/feed/",
    "news1":            "https://www.news1.co.il/rss",
    "0404":             "https://www.0404.co.il/feed/",
    "srugim":           "https://www.srugim.co.il/feed",
    "kikar":            "https://www.kikar.co.il/feed",
    "bhol":             "https://www.bhol.co.il/feed",
    "hidabroot":        "https://www.hidabroot.com/rss",
    "arutz7":           "https://www.inn.co.il/rss.aspx",

    # === כלכלה ועסקים ===
    "calcalist":        "https://www.calcalist.co.il/rss/AjaxPage,7340,L-madorss,00.xml",
    "calcalist_hitech": "https://www.calcalist.co.il/rss/AjaxPage,7340,L-madorss_hitech,00.xml",
    "globes":           "https://www.globes.co.il/webservice/rss/rssfeeder.asmx/FeedByCategory?iCategoryId=4&iChannelId=1",
    "globes_tech":      "https://www.globes.co.il/webservice/rss/rssfeeder.asmx/FeedByCategory?iCategoryId=17",
    "themarker":        "https://www.themarker.com/srv/special/rss/tm_feed.xml",
    "ynet_economy":     "https://www.ynet.co.il/Integration/StoryRss6.xml",
    "walla_econ":       "https://rss.walla.co.il/feed/2",
    "bizportal":        "https://www.bizportal.co.il/rss/rss.xml",
    "funder":           "https://funder.co.il/feed/",
    "geektime":         "https://www.geektime.co.il/feed/",
    "nocamels":         "https://nocamels.com/feed/",
    "techtime":         "https://techtime.news/feed/",
    "startupnation":    "https://startupnationcentral.org/feed/",

    # === ספורט ===
    "sport5":           "https://www.sport5.co.il/rss.aspx",
    "one":              "https://www.one.co.il/rss/",
    "walla_sport":      "https://rss.walla.co.il/feed/3",
    "ynet_sport":       "https://www.ynet.co.il/Integration/StoryRss4.xml",

    # === בידור ותרבות ===
    "mako_entertainment": "https://rcs.mako.co.il/rss/entertainment.xml",
    "walla_culture":    "https://rss.walla.co.il/feed/7",
    "xnet":             "https://xnet.co.il/feed/",
    "nana10":           "https://nana10.co.il/rss/",

    # === אזורי / מקומי ===
    "mynet":            "https://www.mynet.co.il/rss/",
    "ice":              "https://www.ice.co.il/rss",
    "wnet":             "https://wnet.co.il/feed/",
}

@dataclass
class Article:
    title: str
    summary: str
    url: str
    source: str
    published: datetime

async def fetch_feed(session, name, url):
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            if resp.status != 200:
                return []
            content = await resp.text()
        feed = feedparser.parse(content)
        articles = []
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        for entry in feed.entries:
            pub = None
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                pub = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
            if pub and pub < cutoff:
                continue
            summary = ""
            if hasattr(entry, "summary"):
                summary = entry.summary[:500]
            elif hasattr(entry, "description"):
                summary = entry.description[:500]
            articles.append(Article(title=entry.get("title", "").strip(), summary=summary.strip(), url=entry.get("link", ""), source=name, published=pub or datetime.now(timezone.utc)))
        return articles
    except Exception as e:
        logger.error(f"Error fetching {name}: {e}")
        return []

async def fetch_all_articles(extra_industries=None):
    feeds_to_fetch = dict(NEWS_FEEDS)
    if extra_industries:
        for ind in extra_industries:
            if ind in INDUSTRY_FEEDS:
                feeds_to_fetch[f"industry_{ind}"] = INDUSTRY_FEEDS[ind]
    async with aiohttp.ClientSession(headers={"User-Agent": "Mozilla/5.0 (compatible; PRNewsBot/1.0)"}) as session:
        tasks = [fetch_feed(session, name, url) for name, url in feeds_to_fetch.items()]
        results = await asyncio.gather(*tasks)
    all_articles = []
    seen_urls = set()
    for batch in results:
        for article in batch:
            if article.url not in seen_urls:
                seen_urls.add(article.url)
                all_articles.append(article)
    return all_articles
